#!/bin/bash
/opt/ds_agent/dsa_control -r
