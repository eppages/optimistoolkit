#!/bin/bash
echo "This version was created on `date`" > version.txt
