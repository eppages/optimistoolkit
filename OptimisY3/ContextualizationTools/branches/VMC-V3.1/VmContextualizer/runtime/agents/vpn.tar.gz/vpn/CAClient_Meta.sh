#!/bin/bash
/opt/optimis/vpn/install_CAClient.sh
sleep 60
/opt/optimis/vpn/deploy_CAClient.sh > /opt/optimis/vpn/install.log 2>&1 &
