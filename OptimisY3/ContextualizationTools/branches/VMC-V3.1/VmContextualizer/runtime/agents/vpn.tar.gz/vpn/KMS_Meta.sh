#!/bin/bash
/opt/optimis/vpn/deps_KMS.sh
/bin/mount -t nfs 109.231.66.83:/SecVol/ /optimis-sec-storage/
