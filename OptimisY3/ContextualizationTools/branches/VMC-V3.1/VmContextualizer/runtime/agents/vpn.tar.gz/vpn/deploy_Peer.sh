#!/bin/bash
cd /opt/optimis/vpn/P2PVPN/target/
java -jar P2PVPN-3.0-jar-with-dependencies.jar
