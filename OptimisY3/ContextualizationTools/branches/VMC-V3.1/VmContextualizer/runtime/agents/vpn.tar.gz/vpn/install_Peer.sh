#!/bin/bash
tar xzf /opt/optimis/vpn/P2PVPN.tar.gz -C /opt/optimis/vpn/
