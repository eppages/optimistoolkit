#!/bin/bash
/usr/bin/yum install nfs-utils nfs-utils-lib -y
