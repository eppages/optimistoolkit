#!/bin/bash
/bin/rpm -evv `/bin/rpm -qa | /bin/grep ds_agent`
