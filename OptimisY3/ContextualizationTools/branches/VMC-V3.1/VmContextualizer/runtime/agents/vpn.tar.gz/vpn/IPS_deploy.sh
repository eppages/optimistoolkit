#!/bin/bash
/bin/rpm -ivh /opt/optimis/vpn/Agent-RedHat_EL6-9.0.0-883.x86_64.rpm

/opt/ds_agent/dsa_control -r >> /opt/optimis/vpn/dsa.log 2>&1

/opt/ds_agent/dsa_control -a dsm://109.231.67.179:4120/ tenantID:8162D5D2-F69A-5E18-508B-401CED6A43FD tenantPassword:3958B558-8413-FD33-6F59-0EF628595BDE "policyid:1" "groupid:3" >> /opt/optimis/vpn/dsa.log 2>&1
